import numpy as np
from sympy import *
# 目标函数：f(x,y) = x**2 + y**2 + 2*x*y + 4*x + 6*y + 7
#x,y=symbols('x,y')
def func(x, y):
    return 100*x**4-200*x**2*y+x**2-2*x+100*y**2+1
# 目标函数的一阶导数
def grad_func(x, y):
    grad_x = 400*x**3-400*x*y+2*x-2
    grad_y = -200*x**2+200*y
    return np.array([grad_x, grad_y])

# 目标函数的二阶导数
def hessian_func(x, y):
    hess_xx = 1200*x**2-400*y+2
    hess_xy = -400*x
    hess_yx = -400*x
    hess_yy = 200
    return np.array([[hess_xx, hess_xy], [hess_yx, hess_yy]])

# 牛顿迭代法求解最小值
def newton_method(x0, y0, eps=1e-6, max_iter=1000):
    x = np.array([x0, y0])
    iter_num = 0
    while iter_num < max_iter:
        iter_num += 1
        grad = grad_func(x[0], x[1])
        hessian = hessian_func(x[0], x[1])
        if np.linalg.norm(grad) < eps:
            break
        dx = np.linalg.inv(hessian) @ grad
        x = x - dx
        print("iter: {}, x: {}, f(x): {}".format(iter_num, x, func(x[0], x[1])))
    return x, iter_num

# 测试
x0, y0 = 2.6, 8.9
x, iter_num = newton_method(x0, y0)
print("初始点：(x0, y0) = ({}, {})".format(x0, y0))
print("最小值点：(x*, y*) = ({}, {})".format(x[0], x[1]))
print("迭代次数：k = {}".format(iter_num))
print("最小值：f(x*, y*) = {}".format(func(x[0], x[1])))