import numpy as np

A = np.zeros((100, 100))
for i in range(100):  # generate A
    for j in range(100):
        if (i == j):
            A[i, j] = 2
        if (abs(i - j) == 1):
            A[i, j] = A[j, i] = -1
b = np.ones((100, 1))  # generate b
b=b*1.5
b[0,0]=2.5
b[99,0]=2.5
b[49,0]=1.0
b[50,0]=1.0
x0 = np.ones((100, 1))  # 初始值x0
# 定义迭代初值 x0 和迭代误差
eps = 1e-4
# 开始迭代
x= x0.copy()
n = len(x)
k = 0
while True:
    k += 1
    x_new = np.zeros(n)
    for i in range(n):
        s1 = np.dot(A[i, :i], x_new[:i])
        s2 = np.dot(A[i, i+1:], x[i+1:])
        x_new[i] = (b[i] - s1 - s2) / A[i, i]
        # 计算迭代误差
    err = np.linalg.norm(x_new - x)
        # 更新迭代结果
    x = x_new
        # 输出迭代步骤
    print("第 %d 步迭代结果：" % k, x)
        # 判断是否满足迭代停止条件
    if err < eps:
        break
print("迭代得到的近似解为：", x)
print("实际误差值为：", err)
print(x)  # 输出解向量
