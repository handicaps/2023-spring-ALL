import numpy as np
import math


def f(x):
    return (1 - x[0])**2 + 100 * (x[1] - x[0]**2)**2

def rosenbrock_gradient(x):
    """Gradient of Rosenbrock function"""
    df_dx1 = 2 * (200 * x[0]**3 - 200 * x[0] * x[1] + x[0] - 1)
    df_dx2 = 200 * (x[1] - x[0]**2)
    return np.array([df_dx1, df_dx2])


def armijo_step_size(x, gradient, alpha=1.0, beta=0.5):
    """Compute step size using Armijo's rule"""
    step_size = alpha
    while f(x - step_size * gradient) > f(x) - beta * step_size * np.linalg.norm(gradient)**2:
        step_size *= beta
    return step_size


def gradient_descent(x0):
    """Gradient descent optimization"""
    x = x0
    count = 0
    gradient = rosenbrock_gradient(x)
    while math.sqrt(pow(gradient[0], 2) + pow(gradient[1], 2)) > 0.0000001:
        gradient = rosenbrock_gradient(x)
        step_size = armijo_step_size(x, gradient)
        x -= step_size * gradient
        count += 1
        print('第', count, '次迭代:', 'x=', x[0], 'y=', x[1])
    return x

# Initial point
x0 = np.array([-0.3, 0.4])

# Run gradient descent optimization
optimal_point = gradient_descent(x0)

print("Optimal point:", optimal_point)
print("Minimum value:", f(optimal_point))
